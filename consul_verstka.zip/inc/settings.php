<?
  include("admin/inc/const.php");
  include("admin/inc/connect.php");
  include("inc/session.php");
  require_once("inc/functions.php");
?>
