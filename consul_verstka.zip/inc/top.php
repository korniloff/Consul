<table Border=0 CellSpacing=0 CellPadding=0 class=wrtable>
 <tr valign=top>
    <td class=leftbg>&nbsp;</td>
    <td class=page>

    <?
       include("inc/mainmenu.php");
       include("inc/logo_search.php");
       include("inc/toptext.php");
    ?>
