      <div class=leftpart>

         <?
             include("inc/catalogmenu.php");
             include("inc/leftcontacts.php");
         ?>

      </div>
