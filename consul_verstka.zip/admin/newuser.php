<?php

$user_pass=md5('gs4172');
echo "$user_pass <BR>";

?>