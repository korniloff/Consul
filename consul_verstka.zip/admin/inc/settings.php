<?php
  setlocale(LC_CTYPE, 'ru_RU.CP1251');
  include("connect.php");
  include("const.php");
  include("session.php");
  require_once("functions.php");
?>
