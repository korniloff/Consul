<?php

    $PREFFIX="consul";
    $mainurl="http://localhost/consul";
    $adminemail="pu88@mail.ru";
    $adminname="������";
//    if (!isset($backpage))$backpage="main.php";
?>
